package com.epam.chorniak;

public class ArrayInverter {
	public static void  invert (int[] arr) {
		for (int i = (arr.length / 2) - 1; i >= 0; i--){
			int tmp = arr[i];
			arr[i] = arr[arr.length-1-i];
			arr[arr.length-1-i] = tmp;
		}
	}
	public static int[] merge(int[] first, int[] second){
		int[] result = new int[first.length + second.length];
		int firstIndex = 0;
		int secondIndex = 0;
		while (firstIndex + secondIndex < result.length){
			if (firstIndex == first.length) {
				System.arraycopy(second, secondIndex, result, firstIndex + secondIndex, second.length - secondIndex); 
				return result;
			}
			else if (secondIndex == second.length) {
				System.arraycopy(first, firstIndex, result, firstIndex + secondIndex, first.length - firstIndex); 
				return result;
			}
			else  if (first[firstIndex] < second[secondIndex]){
				result[firstIndex + secondIndex] = first[firstIndex++];
			}
			else{
				result[firstIndex + secondIndex] = second[secondIndex++];   
			}
			
			
		}
		return result;
	}

}
