package com.epam.chorniak;

import java.util.Arrays;

public class Demo {

	public static void main(String[] args) {
		int arr[] = {1,2,3,4,5};
		ArrayInverter.invert(arr);
		System.out.println(Arrays.toString(arr));
		
		int first[] = {2,5,7,9};
		int second[] = {3,4,6};
		System.out.println(Arrays.toString(ArrayInverter.merge(first, second)));
		
		

	}

}
